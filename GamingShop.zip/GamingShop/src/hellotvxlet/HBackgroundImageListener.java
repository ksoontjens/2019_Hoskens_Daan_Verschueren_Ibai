

package hellotvxlet;

/**
 *
 * @author student
 */
interface HBackgroundImageListener {
    
}
